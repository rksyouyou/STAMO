
f1 <- function(x) rev(cumsum(rev(x)))

f2 <- function(x) x%*%t(x)

## Fisher
fisher <- function(pvec){
  n = length(pvec)
  q = -2*(sum(log(pvec)))
  1- pchisq(q,2*n)
}


## score, efficient score, variance for survival 
ST_surv <- function(est,M1,M2,delta){

    n = length(delta)
    n1 = ncol(M1)
    n2 = ncol(M2)
    
    ## fit the model under H01
    M2est =  as.vector(exp(M2%*%est))
    M2est_f = f1(M2est)
    M1_M2est_f = apply(M1*M2est,2,f1)
    A1 = M1_M2est_f/M2est_f
    R1 = (M1 -  A1)*delta # score_interested
    U1 = matrix(colSums(R1))

    M2_M2est_f = apply(M2*M2est,2,f1)
    A2 = M2_M2est_f/M2est_f 
    R2 = (M2-A2)*delta # score_nuisance

    ## I_interested/interested
    if(n1 > 1){
        M1f2 = t(apply(M1,1,f2))
        M1f2_M2est_f = apply(M1f2*M2est,2,f1)
        A1f2 = t(apply(A1,1,f2))
        I_11 = matrix(colSums((M1f2_M2est_f/M2est_f - A1f2)*delta),n1,n1)
    }
    if(n1 == 1){
        M1f2 = M1^2
        M1f2_M2est_f = apply(M1f2*M2est,2,f1)
        A1f2 = A1^2
        I_11 = sum((M1f2_M2est_f/M2est_f - A1f2)*delta)
    }
    
    ## I_nuisance/nuisance
    if(n2 > 1){
        M2f2 = t(apply(M2,1,f2))
        M2f2_M2est_f = apply(M2f2*M2est,2,f1)
        A2f2 = t(apply(A2,1,f2))
        I_22 = matrix(colSums((M2f2_M2est_f/M2est_f - A2f2)*delta),n2,n2)
    }
    if(n2 == 1){
        M2f2 = M2^2
        M2f2_M2est_f = apply(M2f2*M2est,2,f1)
        A2f2 = A2^2
        I_22 = sum((M2f2_M2est_f/M2est_f - A2f2)*delta)
    }
    
    ## I_interested/nuisance
    if(n1==1&n2==1){
        M12 = M1*M2
        M12_M2est_f = apply(M12*M2est,2,f1)
        A32 = M1_M2est_f*M2_M2est_f/M2est_f^2
        I_12 = sum((M12_M2est_f/M2est_f - A32)*delta)
    } else {
        M12 = t(apply(cbind(M1,M2),1,function(x) x[1:n1]%*%t(x[(n1+1):(n1+n2)])))
        M12_M2est_f = apply(M12*M2est,2,f1)
        A32 = t(apply(cbind(M1_M2est_f,M2_M2est_f),1,function(x) x[1:n1]%*%t(x[(n1+1):(n1+n2)])))/M2est_f^2
        I_12 = matrix(colSums((M12_M2est_f/M2est_f - A32)*delta),nrow=n1,ncol=n2)
    }
    
    ## Efficient scores
    K1 = matrix(NA,n,n1)
    K2 = matrix(NA,n,n2)
    for(i in 1:n){
        tmp1 = tmp2  = 0
        for(j in 1:i){
            tmp1 = tmp1 + delta[j]*(M2est[i]/M2est_f[j])*(M1[i,] - A1[j,])
            tmp2 = tmp2 + delta[j]*(M2est[i]/M2est_f[j])*(M2[i,] - A2[j,])
        }
        K1[i,] = R1[i,] - tmp1
        K2[i,] = R2[i,] - tmp2
    }

    E = K1 - t(I_12%*%solve(I_22)%*%t(K2))

    ## variance of R1/E
    V = I_11 - I_12%*%solve(I_22)%*%t(I_12)

    return(list(E=E, V=V))
}

ST_binary <- function(est,M1,M2,Y){

    M2 = cbind(1,M2)
    n1 = ncol(M1)
    n2 = ncol(M2)
    mi = which(is.na(Y)) # missing indicator
    mv = ifelse(is.na(Y),0,1)
    
    M2est =  as.vector(exp(M2%*%est))
    mu = M2est/(1+M2est)
    R1 = (Y-mu)*M1 # score_interested
    R2 = (Y-mu)*M2 # score_nuisance
    R1[mi,] = 0
    R2[mi,] = 0

    M12 = t(apply(cbind(M1,M2),1,function(x) x[1:n1]%*%t(x[(n1+1):(n1+n2)])))
    mu2 = M2est/(1+M2est)^2
    I_11 = matrix(colSums(t(apply(M1,1,f2))*mv*mu2),n1,n1)  # I_interested/interested
    I_12 = matrix(colSums(M12*mu2*mv),n1,n2)# I_interested/nuisance
    I_22 = matrix(colSums(t(apply(M2,1,f2))*mv*mu2),n2,n2) # I_nuisance/nuisance

    ## efficient score 
    E = R1 - t(I_12%*%solve(I_22)%*%t(R2))

    ## variance of R1/E
    V = I_11 - I_12%*%solve(I_22)%*%t(I_12)

    return(list(E=E, V=V))    
}

ST_continuous <- function(est,M1,M2,Y){

    M2 = cbind(1,M2)
    n = nrow(M1)
    n1 = ncol(M1)
    n2 = ncol(M2)
    mi = which(is.na(Y)) # missing indicator
    mv = ifelse(is.na(Y),0,1)

    mu =  as.vector(M2%*%est)
    resid = Y-mu
    resid[mi] = 0
    sig2inv = (sum(mv)-n2)/sum(resid^2,na.rm=TRUE)

    R1 = sig2inv*resid*M1*mv # score_interested
    R2 = sig2inv*resid*M2*mv # score_nuisance

    I_11 = sig2inv*t(M1*mv)%*%(M1*mv)
    I_12 = sig2inv*t(M1*mv)%*%(M2*mv)
    I_22 = sig2inv*t(M2*mv)%*%(M2*mv)
    
    ## efficient score 
    E = R1 - t(I_12%*%solve(I_22)%*%t(R2))

    ## variance of R1/E
    V = I_11 - I_12%*%solve(I_22)%*%t(I_12)

    return(list(E=E, V=V))    
}

STAMO_H0<- function(U,delta,Y_bin,Y_cont,X,G,W){

    ## check the data format
    n = length(U)
    p = ncol(G)
    if(length(delta)!=n|length(Y_bin)!=n|nrow(X)!=n|nrow(G)!=n) stop('Error! The number of subjects should be consistent across variables!')
    if(ncol(G)!=ncol(W)) stop('Error! The number of somatic mutations should be consistent across variables!')

    ## reorder the data
    o = order(U)
    U = U[o]
    X = X[o,,drop=FALSE]
    G = G[o,]
    delta = delta[o]
    Y_bin= Y_bin[o]
    Y_cont= Y_cont[o]
    GW = G%*%t(W)
    M = cbind(X,GW)

    n1 = ncol(GW)
    n2 = ncol(G)

    ## scores
    out1 = ST_surv(suppressWarnings(coxph(Surv(U,delta)~X))$coefficients,GW,X,delta) # surv_fixed
    out2 = ST_surv(suppressWarnings(coxph(Surv(U,delta)~M))$coefficients,G,M,delta) # surv_random
    
    bout1 = ST_binary(glm(Y_bin~X,family='binomial')$coef,GW,X,Y_bin) # bin_fixed
    bout2 = ST_binary(glm(Y_bin~M,family='binomial')$coef,G,M,Y_bin) # bin_random
    
    cout1 = ST_continuous(lm(Y_cont~X)$coef,GW,X,Y_cont) # cont_fixed
    cout2 = ST_continuous(lm(Y_cont~M)$coef,G,M,Y_cont) # cont_random
    

    ## joint: surv-bin
    ## fix
    Ef <- cbind(out1$E,bout1$E)
    Uf <- matrix(colSums(Ef))
    Vf <- matrix(rowSums(apply(Ef,1,f2)),nrow=n1*2,ncol=n1*2)
    Qf <- t(Uf)%*%solve(Vf)%*%Uf
    bpval1_joint= 1-pchisq(Qf,2*n1)
    
    ## random
    Er <- cbind(out2$E,bout2$E)
    Ur <- matrix(colSums(Er))
    Vr <- matrix(rowSums(apply(Er,1,f2)),nrow=n2*2,ncol=n2*2)
    Qr = t(Ur)%*%Ur
    lam =eigen(Vr,symmetric = TRUE)$values
    bpval2_joint = davies(Qr,lam,lim=5000,acc=1e-04)$Qq
    if(bpval2_joint<0) bpval2_joint = liu(Qr,lam)

    ## joint: surv-bin
    ## fix
    Ef <- cbind(out1$E,cout1$E)
    Uf <- matrix(colSums(Ef))
    Vf <- matrix(rowSums(apply(Ef,1,f2)),nrow=n1*2,ncol=n1*2)
    Qf <- t(Uf)%*%solve(Vf)%*%Uf
    cpval1_joint= 1-pchisq(Qf,2*n1)
    
    ## random
    Er <- cbind(out2$E,cout2$E)
    Ur <- matrix(colSums(Er))
    Vr <- matrix(rowSums(apply(Er,1,f2)),nrow=n2*2,ncol=n2*2)
    Qr = t(Ur)%*%Ur
    lam =eigen(Vr,symmetric = TRUE)$values
    cpval2_joint = davies(Qr,lam,lim=5000,acc=1e-04)$Qq
    if(cpval2_joint<0) cpval2_joint = liu(Qr,lam)
    
    ## independent 
    ## surv fix
    Uf <- matrix(colSums(out1$E))
    Qf <- t(Uf)%*%solve(out1$V)%*%Uf
    pval1a_surv  = 1-pchisq(Qf,n1)

    ## survival random
    Ur <- matrix(colSums(out2$E))
    Qr = t(Ur)%*%Ur
    lam =eigen(out2$V,symmetric = TRUE)$values
    pval2a_surv = davies(Qr,lam,lim=5000,acc=1e-04)$Qq
    if(pval2a_surv<0) pval2a_surv = liu(Qr,lam)
    
    ## score test for variance component
    out = c(bpval1_joint,bpval2_joint,cpval1_joint,cpval2_joint,pval1a_surv,pval2a_surv)
    names(out) = c('fix_joint_b','rand_joint_b','fix_joint_c','rand_joint_c','fix_surv','rand_surv')
    return(out)

}


