rm(list=ls())


source('auxfuns/aux_funs.R')
source('auxfuns/pkg.R')
source('auxfuns/simudat_H0.R')
source('auxfuns/frun_H0.R')
source('auxfuns/STAMO_H0.R')

seed = readRDS('dat/seed1M.rds')
snpdat = readRDS('dat/ENC1_snpdat.rds')
paras_bin = readRDS('paras/b_S0.rds')
paras_cont = readRDS('paras/c_S0.rds')

for(n in c(2000,2500,3000))
    for(p in c(15,20)){
        out = NULL        
        for(i in 1:10^6)
            out = rbind(out,forall(bset[i],n,p,snpdat,paras_bin,paras_cont))
        saveRDS(out,paste0('res/S0_n',n,'_p',p,'_',b,'.rds'))
    }
    

for(n in c(2000,2500,3000))
    for(p in c(15,20)){
        dat = readRDS(paste0('./res/S0_n',n,'_p',p,'.rds'))
        head(dat)
        loc = paste0('./res/S0/')
        cname = paste0('_S0_n',n,'_p',p,'_nv',nv,'.rds')
        ##
        saveRDS(dat[,c(1,2)],paste0(loc,'bin_burden',cname))
        saveRDS(dat[,c(1,3)],paste0(loc,'cont_burden',cname))
        saveRDS(dat[,c(4,5)],paste0(loc,'bin_CoxmRand',cname))
        saveRDS(dat[,c(4,6)],paste0(loc,'cont_CoxmRand',cname))
        saveRDS(dat[,c(7:9)],paste0(loc,'bin_MiST',cname))
        saveRDS(dat[,c(10:12)],paste0(loc,'cont_MiST',cname))
        saveRDS(dat[,c(13,14,17,18)],paste0(loc,'bin_prop',cname))
        saveRDS(dat[,c(15:18)],paste0(loc,'cont_prop',cname))
    }


out = NULL
pname = NULL
a = 0.001
s = 0
nv = 5
for(t in c('bin','cont')) # 
    for(n in c(2000,2500,3000))  # 
        for(p in c(15,20)){
            dat = readRDS(paste0('./res/S0_n',n,'_p',p,'.rds'))
            pname = c(pname,paste0(t,'-n',n,'-p',p))
            cname = paste0('_S',s,'_n',n,'_p',p,'_nv',nv,'.rds')
            loc = paste0('./res/S',s,'/')
            burden = apply(readRDS(paste0(loc,t,'_burden',cname)),1,min)*2
            CoxmRand = apply(readRDS(paste0(loc,t,'_CoxmRand',cname)),1,min)*2
            mist_bio = readRDS(paste0(loc,t,'_MiST',cname))[,3]
            prop = readRDS(paste0(loc,t,'_prop',cname))
            mist_surv = apply(prop[,3:4],1,fisher)
            CoxMiST = pmin(mist_bio,mist_surv)*2
            joint_fisher = apply(prop[,1:2],1,fisher)
            joint_acat = apply(prop[,1:2],1,cct)
            pmat = cbind(burden,CoxmRand,CoxMiST,joint_fisher,joint_acat)
            out= rbind(out,colMeans(pmat<a,na.rm=TRUE)/a)
        }

