rm(list=ls())


source('auxfuns/aux_funs.R')
source('auxfuns/pkg.R')
source('auxfuns/simudat.R')
source('auxfuns/frun_H1.R')
source('auxfuns/STAMO.R')


## 
seed = readRDS('dat/seed1M.rds')
snpdat = readRDS('dat/ENC1_snpdat.rds')

for(t in c('bin','cont'))
    for(s in 1:3)
        for(p in c(15,20)){
            paras = readRDS(paste0('paras/',substr(t,1,1),'_S',s,'_p',p,'.rds'))
            if(n == 2000) c0 = 1
            if(n == 2500) c0 = 0.9
            if(n == 3000) c0 = 0.8
            paras$theta1 = paras$theta1*c0
            paras$theta2 = paras$theta2*c0
            ##
            res = NULL
            for(i in bset){
                out = fall(i,n,p,snpdat,nv=0.5,paras,type = t)    
                burden = min(out[1:2])*2
                CoxmRand = min(out[3:4])*2
                CoxMiST = min(out[7],fisher(out[12:13]))*2 
                stamo_fisher  = fisher(out[8:9])
                stamo_acat = cct(out[8:9])
                pvec = cbind(burden,CoxmRand,CoxMiST,stamo_fisher,stamo_acat)
                res = rbind(res,pvec)
            }
            saveRDS(res,paste0('res/S',s,'_',t,'_n',n,'_p',p,'.rds'))
        }

