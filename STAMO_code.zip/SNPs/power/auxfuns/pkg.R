library(hapsim) # for data simulation
## method
library(MiST)
library(survival)
library(CompQuadForm)
library(SKAT)
library(statmod) # score test for glm

