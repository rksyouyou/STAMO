## Cauchy combination test
cct <- function(pvec,weight=NULL){
    J = length(pvec)
    if(is.null(weight)) weight = rep(1/J,J)
    t0 = sum(tan((0.5-pvec)*pi)*weight)
    pval = 0.5-atan(t0/sum(weight))/pi
    pval
}
