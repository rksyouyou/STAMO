MAFfun <- function(snpdat){
    ## row - sample
    ## col - snps 
    nsample = nrow(snpdat)
    excf <- function(x){
        exc_vec = as.numeric(do.call(rbind,strsplit(x,'|'))[,c(1,3)])
        exc_vec[exc_vec>1] = 1
        sum(exc_vec)
    }
    ndom_vec = apply(snpdat,2,excf)
    ndom_vec/nsample/2
}

