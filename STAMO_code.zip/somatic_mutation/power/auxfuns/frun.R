## burden method
fburden <- function(i,n,nv,paras,type = c('bin','cont')){
    attach(paras)
    if(type=='bin') dat = simudat(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma=NULL,type,seed[i])
    if(type=='cont') dat = simudat(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma,type,seed[i])
    detach(paras)

    pval_surv <- burden_surv(dat,type)
    pval_bio <- burden_bio(dat,type)
    pvec <- c(pval_surv,pval_bio)
    return(pvec)
}

burden_bio <- function(dat,type = c('bin','cont')){
    
    M1 = matrix(rowSums(dat$G)) # collapse
    M2 = cbind(1,dat$X)
    n1 = ncol(M1)
    n2 = ncol(M2)
    Y = dat$Y

    if(type =='bin'){
        est = glm(Y~0+M2,family='binomial')$coef
        M2est =  as.vector(exp(M2%*%est))
        mu = M2est/(1+M2est)
        R1 = (Y-mu)*M1 # score_interested
        M12 = t(apply(cbind(M1,M2),1,function(x) x[1:n1]%*%t(x[(n1+1):(n1+n2)])))
        mu2 = M2est/(1+M2est)^2
        I_11 = sum(M1^2*mu2)  # I_interested/interested
        I_12 = matrix(colSums(M12*mu2),n1,n2)# I_interested/nuisance
        I_22 = matrix(colSums(t(apply(M2,1,f2))*mu2),n2,n2) # I_nuisance/nuisance
    }

    if(type =='cont'){
        est = lm(Y~0+M2)$coef
        mu =  as.vector(M2%*%est)
        resid = Y-mu
        sig2inv = (n-n2)/sum(resid^2)
        R1 = sig2inv*resid*M1 # score_interested
        I_11 = sig2inv*t(M1)%*%(M1)
        I_12 = sig2inv*t(M1)%*%(M2)
        I_22 = sig2inv*t(M2)%*%(M2)
    }
    
    ## variance of R1
    V = I_11 - I_12%*%solve(I_22)%*%t(I_12)
    Q <- sum(R1)^2/V
    1-pchisq(Q,n1)
}

burden_surv <- function(dat,type = c('bin','cont')){
    
    ## reorder the data
    o = order(dat$U)
    U = dat$U[o]
    X = dat$X[o,]
    G = dat$G[o,]
    delta = dat$delta[o]
    Y = dat$Y[o]

    M1 = matrix(rowSums(G)) # collapse
    M2 = X
    n1 = ncol(M1)
    n2 = ncol(M2)
    est = coxph(Surv(U,delta)~X)$coefficients

    ## fit the model under H01
    M2est =  as.vector(exp(M2%*%est))
    M2est_f = f1(M2est)
    M1_M2est_f = f1(M1*M2est)
    A1 = M1_M2est_f/M2est_f
    R1 = (M1 -  A1)*delta # score_interested
    U1 = matrix(colSums(R1))
    M2_M2est_f = apply(M2*M2est,2,f1) # n*p
    A2 = M2_M2est_f/M2est_f  # n*p

    ## I_interested/interested
    M1f2 = M1^2    
    M1f2_M2est_f = apply(M1f2*M2est,2,f1)
    A1f2 = A1^2
    I_11 = sum((M1f2_M2est_f/M2est_f - A1f2)*delta)
    
    ## I_nuisance/nuisance
    M2f2 = t(apply(M2,1,f2))
    M2f2_M2est_f = apply(M2f2*M2est,2,f1)
    A2f2 = t(apply(A2,1,f2))
    I_22 = matrix(colSums((M2f2_M2est_f/M2est_f - A2f2)*delta),n2,n2)

    ## I_interested/nuisance
    M12 = t(apply(cbind(M1,M2),1,function(x) x[1:n1]%*%t(x[(n1+1):(n1+n2)])))
    M12_M2est_f = apply(M12*M2est,2,f1)
    A32 = t(apply(cbind(M1_M2est_f,M2_M2est_f),1,function(x) x[1:n1]%*%t(x[(n1+1):(n1+n2)])))/M2est_f^2
    I_12 = matrix(colSums((M12_M2est_f/M2est_f - A32)*delta),nrow=n1,ncol=n2)

    ## variance of R1/E
    V = I_11 - I_12%*%solve(I_22)%*%t(I_12)

    Uf <- sum(R1)
    Qf <- Uf^2/V
    pval  = 1-pchisq(Qf,n1)

    pval
}


## Cox-mRand
Cox_mRand <-  function(i,n,nv,paras,type){
    attach(paras)
    if(type=='bin') dat = simudat(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma=NULL,type,seed[i])
    if(type=='cont') dat = simudat(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma,type,seed[i])
    detach(paras)
    
    ## biological response
    if(type=='bin'){
        obj <- SKAT_Null_Model(dat$Y~dat$X,out_type='D',Adjustment=FALSE)
        pval_bio <- SKAT(dat$G,obj,kernel='linear')$p.value
    }
    if(type=='cont'){
        obj <- SKAT_Null_Model(dat$Y~dat$X,out_type='C',Adjustment=FALSE)
        pval_bio<- SKAT(dat$G,obj,kernel='linear')$p.value
    }
    
    ## survival outcome
    o = order(dat$U) # reorder the data
    U = dat$U[o]
    X = dat$X[o,]
    G = dat$G[o,]
    delta = dat$delta[o]
    out = ST_surv(coxph(Surv(U,delta)~X)$coefficients,G,X,delta) # adopot the same proc in the proposed method
    Ur <- matrix(colSums(out$E))
    Qr = t(Ur)%*%Ur
    lam =eigen(out$V,symmetric = TRUE)$values
    pval = davies(Qr,lam,lim=5000,acc=1e-04)$Qq
    if(pval<0) pval = liu(Qr,lam)

    pvec <- c(pval,pval_bio)
    return(pvec)
}

## Cox-MiST
CoxMiST_bio <-  function(i,n,nv,paras,type){
    attach(paras)
    if(type=='bin') dat = simudat(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma=NULL,type,seed[i])
    if(type=='cont') dat = simudat(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma,type,seed[i])
    detach(paras)
    if(type=='bin') return(unlist(logit.test(dat$Y,cbind(1,dat$X),dat$G,t(dat$W))))
    if(type=='cont') return(unlist(linear.test(dat$Y,cbind(1,dat$X),dat$G,t(dat$W))))
}


## proposed method
fpro  <- function(i,n,nv,paras,type){
    attach(paras)
    if(type=='bin') dat = simudat(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma=NULL,type,seed[i])
    if(type=='cont') dat = simudat(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma,type,seed[i])
    detach(paras)
    ## ST(dat,type)
    STAMO(dat$U,dat$delta,dat$Y,dat$X,dat$G,dat$W)
}
