simudat <- function(n,W,censor_para,f_mutation,gamma1,gamma2,theta1,theta2,b1,b2,nv,sigma=NULL,type,seed){

    ## correlated survival and biological data
    set.seed(seed)
    p = ncol(W)
    ## covariates and G
    X = cbind(rbinom(n,1,0.5),rnorm(n)) # survival 
    X2 = cbind(1,X) # biological data 
    G <- replicate(p,rbinom(n,1,f_mutation))

    ## copula
    tmp = mvrnorm(n,rep(0,2),matrix(c(1,nv,nv,1),nrow=2))
    z = pnorm(tmp)

    ## survival outcome 
    lambda0 = 1 # baseline hazard for cox model 
    eta = exp(X%*%gamma1 + G%*%t(W)%*%theta1+G%*%b1)
    T = qexp(z[,1],eta*lambda0)
    Ct = runif(n,0,censor_para)
    U = apply(cbind(T,Ct),1,min)
    delta = ifelse(T<=Ct,1,0) # 1 = dead, 0 = censor

    if(type=='bin'){
        eta2 = exp(X2%*%gamma2 + G%*%t(W)%*%theta2+G%*%b2)
        prob = eta2/(eta2+1)
        Y = qbinom(z[,2],1,prob)
    } else {
        eta2 = X2%*%gamma2 + G%*%t(W)%*%theta2+G%*%b2
        Y = qnorm(z[,2],eta2,sigma)
    }

    ## output 
    dat = list(U=U,T=T,Ct=Ct,delta=delta,Y=Y,X=X,G=G,W=W,seed=seed)
    return(dat)
}

