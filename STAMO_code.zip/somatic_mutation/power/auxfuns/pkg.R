## method 
library(MiST)
library(survival)
library(CompQuadForm)
library(SKAT)
library(statmod) # score test for glm
## computing 
library(parallel)
library(pbapply)
## simulation
library(MASS)
## output
library(xtable)
library(ggplot2)


