rm(list=ls())


source("../auxfuns/pkg.R")
source("../auxfuns/frun.R")
source("../auxfuns/STAMO.R")
source("../auxfuns/simudat.R")
seed = readRDS('../dat/seed1M.rds')
nc = Sys.getenv('SLURM_JOB_CPUS_PER_NODE', unset=4)


nv = 0.5
B = 1:10^6
bset = 1:B

for(s in 1:3)
    for(p in c(10,15))
        for(n in c(1500,2000,2500))
            for(type in c('bin','cont')){
                paras = readRDS(paste0('../dat/S',s,'/',substr(type,1,1),'_S',s,'_n',n,'_p',p,'.rds'))
                cname = paste0('_S',s,'_n',n,'_p',p,'_nv',nv*10,'_b',b,'.rds')
                ## burden
                system.time({res= do.call(rbind,mclapply(bset,fburden,n,nv,paras,type))})
                saveRDS(res,paste0('../res/',type,'_burden_S',cname))
                ## Cox-MiST-bio
                res = do.call(rbind,mclapply(bset,CoxMiST_bio,n,nv,paras,type,mc.cores=nc))
                saveRDS(res,paste0('../res/',type,'_MiST_S',cname))
                ## Cox-mRand
                system.time({res= do.call(rbind,mclapply(bset,Cox_mRand,n,nv,paras,type,mc.cores=nc))})
                saveRDS(res,paste0('../res/',type,'_CoxmRand_S',cname))
                ## proposed method
                system.time({res= do.call(rbind,mclapply(bset,fpro,n,nv,paras,type,mc.cores=nc))})
                saveRDS(res,paste0('../res/',type,'_prop_S',cname))
            }


for(s in 1:3){
    out = NULL
    pname = NULL
    for(t in c('bin','cont'))
        for(n in c(1500,2000,2500)) #
            for(p in c(10,15)){
                pname = c(pname,paste0(t,'_n',n,'_p',p))
                cname = paste0('_S',s,'_n',n,'_p',p,'_nv',nv,'.rds')
                loc = paste0('../res/S',s,'/')
                burden = apply(readRDS(paste0(loc,t,'_burden',cname)),1,min)*2
                CoxmRand = apply(readRDS(paste0(loc,t,'_CoxmRand',cname)),1,min)*2
                mist_bio = readRDS(paste0(loc,t,'_MiST',cname))[,5]
                prop = readRDS(paste0(loc,t,'_prop',cname))
                prop[prop<=0] = delta
                burden[burden==0] = delta
                CoxmRand[CoxmRand==0] = delta
                mist_bio[mist_bio==0] = delta
                mist_surv = apply(prop[,5:6],1,fisher)
                CoxMiST = pmin(mist_bio,mist_surv)*2
                joint_fisher = apply(prop[,1:2],1,fisher)
                joint_acat = apply(prop[,1:2],1,cct)
                pmat = cbind(burden,CoxmRand,CoxMiST,joint_fisher,joint_acat)
                out= rbind(out,colMeans(pmat<a))
            }
    rownames(out) = pname
    print(round(out,3))
}
